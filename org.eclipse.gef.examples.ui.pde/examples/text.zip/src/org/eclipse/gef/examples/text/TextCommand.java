/*******************************************************************************
 * Copyright (c) 2004, 2010 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.gef.examples.text;

/**
 * @since 3.1
 */
public interface TextCommand {

	/**
	 * Returns the viewer's selection range for the state after execution or
	 * redo.
	 * 
	 * @since 3.1
	 * @param viewer
	 *            the viewer
	 * @return the range
	 */
	SelectionRange getRedoSelectionRange(GraphicalTextViewer viewer);

	SelectionRange getExecuteSelectionRange(GraphicalTextViewer viewer);

	/**
	 * Returns the viewer's selection range for the state prior to execution.
	 * 
	 * @since 3.1
	 * @param viewer
	 *            the viewer
	 * @return the range
	 */
	SelectionRange getUndoSelectionRange(GraphicalTextViewer viewer);

}
